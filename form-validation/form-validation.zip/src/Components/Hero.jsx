// import React, { useState } from 'react';

// const Hero = () => {
//   const [currentStep, setCurrentStep] = useState(1);

//   const steps = [
//     { id: 1, label: 'Phone Verification' },
//     { id: 2, label: 'Proof of Funds' },
//     { id: 3, label: 'ID/Driver’s License' },
//     { id: 4, label: 'Business Verification' },
//     { id: 5, label: 'Closer Verification' },
//     { id: 6, label: ' admin verified' },
//   ];

//   return (
//     <section className="bg-gray-100 py-10">
//       <div className="max-w-4xl mx-auto text-center">
//         <h1 className="text-3xl font-bold mb-8"></h1>
//         {/* Stepper */}
//         <div className="flex justify-between items-center w-full max-w-6xl mx-auto">
//           {steps.map((step, index) => (
//             <div key={step.id} className="flex-1 flex items-center relative">
//               {/* Clickable Circle */}
//               <button
//                 onClick={() => setCurrentStep(step.id)}
//                 className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold focus:outline-none transition-all duration-300 ${
//                   currentStep === step.id ? 'bg-blue-600 scale-110' : 'bg-gray-400'
//                 }`}
//               >
//                 {step.id}
//               </button>

//               {/* Label */}
//               <div className="absolute top-12 left-1/2 transform -translate-x-1/2 text-sm font-medium text-gray-700">
//                 {step.label}
//               </div>

//               {/* Line */}
//               {index < steps.length - 1 && (
//                 <div
//                   className={`flex-1 h-1 mx-2 transition-all duration-300 ${
//                     currentStep > step.id ? 'bg-blue-600' : 'bg-gray-300'
//                   }`}
//                 ></div>
//               )}
//             </div>
//           ))}
//         </div>

//         {/* Step Content */}
//         <div className="mt-10 text-lg font-medium text-gray-800">
//           {currentStep === 1 && <p>Step 1: Phone Verification</p>}
//           {currentStep === 2 && <p>Step 2: Proof of Funds</p>}
//           {currentStep === 3 && <p>Step 3: ID/Driver’s License</p>}
//           {currentStep === 4 && <p>Step 4: Business Verification</p>}
//           {currentStep === 5 && <p>Step 5: Closer Verification</p>}
//           {currentStep === 6 && <p>Step 6: admin verified</p>}
//         </div>
//       </div>
//     </section>
//   );
// };

// export default Hero;



import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  const steps = ['Start', 'Details', 'Finish'];
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
  });

  const handleNext = () => {
    if (currentStep === 0 && formData.name.trim() === '') {
      alert('Please enter your name');
      return;
    }
    if (currentStep === 1 && formData.email.trim() === '') {
      alert('Please enter your email');
      return;
    }
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <section className="bg-[url('/your-background.jpg')] bg-cover bg-center min-h-screen flex items-center justify-center">
      <div className="bg-white bg-opacity-90 p-8 rounded shadow-lg w-full max-w-2xl">
        {/* <h1 className="text-3xl font-bold text-center mb-6">Welcome to Our Platform</h1> */}

        {/* Stepper */}
        <div className="flex items-center justify-center mb-6">
          {steps.map((step, index) => (
            <div key={index} className="flex items-center">
              <div
                className={`w-8 h-8 flex items-center justify-center rounded-full text-sm font-semibold ${
                  currentStep >= index ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-600'
                }`}
              >
                {index + 1}
              </div>
              <span className="ml-2 mr-4 text-sm font-medium">{step}</span>
              {index < steps.length - 1 && <ArrowRight className="w-4 h-4 text-gray-500" />}
            </div>
          ))}
        </div>

        {/* Step Form */}
        <div className="text-center mb-6">
          {currentStep === 0 && (
            <input
              type="text"
              placeholder="Enter your name"
              className="w-full border border-gray-300 rounded px-4 py-2"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          )}
          {currentStep === 1 && (
            <input
              type="email"
              placeholder="Enter your email"
              className="w-full border border-gray-300 rounded px-4 py-2"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          )}
          {currentStep === 2 && (
            <div className="text-green-700 font-semibold">
              🎉 Done!<br />
              Name: {formData.name}<br />
              Email: {formData.email}
            </div>
          )}
        </div>

        {/* Buttons */}
        <div className="flex justify-between">
          <button
            onClick={handleBack}
            disabled={currentStep === 0}
            className="px-4 py-2 bg-gray-300 rounded text-sm disabled:opacity-50"
          >
            Back
          </button>
          {currentStep < steps.length - 1 ? (
            <button
              onClick={handleNext}
              className="px-4 py-2 bg-blue-600 text-white rounded text-sm"
            >
              Next
            </button>
          ) : (
            <button className="px-4 py-2 bg-green-600 text-white rounded text-sm">Submit</button>
          )}
        </div>
      </div>
    </section>
  );
};

export default Hero;