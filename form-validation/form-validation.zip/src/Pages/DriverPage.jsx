import React from 'react'
import DriverLicense from '../Components/DriverLicense'

const DriverPage = () => {
  return (
    <>
      <DriverLicense />
    </>
  )
}

export default DriverPage
