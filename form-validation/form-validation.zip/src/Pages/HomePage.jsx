import Hero from '../Components/Hero';

const HomePage = () => {
  return (
    <div>
      <Hero />
    </div>
  );
};

export default HomePage;
