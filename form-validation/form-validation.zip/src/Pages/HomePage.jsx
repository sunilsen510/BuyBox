import Hero from '../Components/Hero';
import ProofOfFunds from '../Components/ProofOfFunds';

const HomePage = () => {
  return (
    <>
      <Hero />
    </>
  );
};

export default HomePage;
