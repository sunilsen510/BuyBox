import React from 'react'
import BussinessVerification from '../Components/BussinessVerification'

const BussinessPage = () => {
  return (
    <>
      <BussinessVerification />
    </>
  )
}

export default BussinessPage
