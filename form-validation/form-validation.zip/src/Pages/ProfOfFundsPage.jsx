// import React from 'react'
// import ProofOfFunds from '../Components/ProofOfFunds'

// const ProfOfFundsPage = () => {
//   return (
//     <>
//       <ProofOfFunds />
//     </>
//   )
// }

// export default ProfOfFundsPage
